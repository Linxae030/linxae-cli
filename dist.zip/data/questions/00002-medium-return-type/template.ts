type MyReturnType<T> = any
