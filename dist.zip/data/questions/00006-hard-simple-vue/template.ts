declare function SimpleVue(options: any): any
