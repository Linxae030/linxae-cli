type MyReadonly2<T, K> = any
