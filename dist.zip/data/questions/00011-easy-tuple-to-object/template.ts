type TupleToObject<T extends readonly any[]> = any
