type First<T extends any[]> = any
