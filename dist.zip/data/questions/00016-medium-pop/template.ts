type Pop<T extends any[]> = any
