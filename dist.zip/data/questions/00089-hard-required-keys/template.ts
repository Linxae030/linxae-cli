type RequiredKeys<T> = any
