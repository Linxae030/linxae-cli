type Trim<S extends string> = any
