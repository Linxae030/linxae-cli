type MyCapitalize<S extends string> = any
