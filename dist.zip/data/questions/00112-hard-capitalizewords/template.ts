type CapitalizeWords<S extends string> = any
