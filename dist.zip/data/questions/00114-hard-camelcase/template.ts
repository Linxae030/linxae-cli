type CamelCase<S extends string> = any
