type MyAwaited<T> = any
