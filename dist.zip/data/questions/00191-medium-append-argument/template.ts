type AppendArgument<Fn, A> = any
