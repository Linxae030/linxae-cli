type Slice<Arr, Start, End> = any
