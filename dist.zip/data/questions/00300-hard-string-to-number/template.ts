type ToNumber<S extends string> = any
