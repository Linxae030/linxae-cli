type Flatten = any
