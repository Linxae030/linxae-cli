type Sum<A extends string | number | bigint, B extends string | number | bigint> = string
