type Multiply<A extends string | number | bigint, B extends string | number | bigint> = string
