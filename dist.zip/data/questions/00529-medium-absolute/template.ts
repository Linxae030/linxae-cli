type Absolute<T extends number | string | bigint> = any
