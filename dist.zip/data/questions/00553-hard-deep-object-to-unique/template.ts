type DeepObjectToUniq<O extends object> = any
