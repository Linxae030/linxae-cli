type DistributeUnions<T> = any
