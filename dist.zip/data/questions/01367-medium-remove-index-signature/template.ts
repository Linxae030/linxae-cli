type RemoveIndexSignature<T> = any
