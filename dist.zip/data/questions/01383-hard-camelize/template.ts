type Camelize<T> = any
