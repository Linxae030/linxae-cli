type PercentageParser<A extends string> = any
