type DropString<S, R> = any
