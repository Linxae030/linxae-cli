type DropChar<S, C> = any
