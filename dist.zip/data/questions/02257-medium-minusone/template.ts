type MinusOne<T extends number> = any
