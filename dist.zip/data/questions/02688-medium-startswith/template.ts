type StartsWith<T extends string, U extends string> = any
