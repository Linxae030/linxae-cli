type EndsWith<T extends string, U extends string> = any
