type PartialByKeys<T, K> = any
